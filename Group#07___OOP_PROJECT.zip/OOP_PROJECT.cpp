#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <iomanip>
#include <windows.h>
using namespace std;

	// Login Class
class Login {
	private:
    string userName, Email, password;
    string searchName, searchPass, searchEmail;
    fstream file;
	public:
    // SignUp Function
	void signUP() {
	cout<<endl<<endl;
    cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;
    cout<<"\t\t\t\t\t\t\t\t\t\t\t\t  Sign UP"<<endl<<endl;
    cout <<"\t\t\t\t\t\t\t\t\t\t\t  Enter Your User Name: ";
    cin.ignore(); 
    getline(cin, userName);
    cout << "\t\t\t\t\t\t\t\t\t\t\t  Enter Your Email Address: ";
    getline(cin, Email);
    cout << "\t\t\t\t\t\t\t\t\t\t\t  Enter Your Password: ";
    getline(cin, password);
    cout<<endl<<endl;
    cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;

    file.open("Login.txt", ios::out | ios::app);
    file << userName << "*" << Email << "*" << password << endl;
    file.close();
    login();
}

	// Login Function
	void login() {
    cout<< endl<<endl;
   
    cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;
     cout<<"\t\t\t\t\t\t\t\t\t\t\t\t  Sign IN"<<endl<<endl;
    cout << "\t\t\t\t\t\t\t\t\t\t\t  Enter Your User Name: ";
    cin.ignore(); 
    getline(cin, searchName);
    cout << "\t\t\t\t\t\t\t\t\t\t\t  Enter Your Password: ";
    getline(cin, searchPass);
    cout<<endl<<endl;
    cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;

    file.open("Login.txt", ios::in);
    getline(file, userName, '*');
    getline(file, Email, '*');
    getline(file, password, '\n');
    bool found = false;
    while (!file.eof()) {
        if (userName == searchName && password == searchPass) {
        	cout<<endl<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t  Account Login Successful...!" << endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t  Username: " << userName << endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t  Email: " << Email << endl<<endl<<endl;
    	    cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;

            found = true;
            break;
        }
        getline(file, userName, '*');
        getline(file, Email, '*');
        getline(file, password, '\n');
    }
    if (!found) {
        cout << "\t\t\t\t\t\t\t\t\t\t\t  Incorrect username or password." << endl;
    }
    file.close();
}
} obj;

	//Project Class

class Project{
	private:
	int id;
    string name,manager, location;
    double budget;
    public:
    	// Add Project Function
    void addProject() {
        ofstream outFile("projects.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        Project p1;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Project ID: ";
        cin >> p1.id;
        cin.ignore();
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Project name: ";
        getline(cin, p1.name);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter budget : $";
        cin >> p1.budget;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Project Manager: ";
        getline(cin, p1.manager);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Project location: ";
        getline(cin, p1.location);

        outFile << p1.id << "|" << p1.name << "|" << p1.budget << "|" << p1.manager << "|" << p1.location << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Project added successfully!" << endl;
    }
    
    // Update Project Function
    void updateProject() {
        ifstream inFile("projects.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Project ID to update: ";
        cin >> id;
        cin.ignore(); 

        Project p2;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> p2.id;
            ss.ignore(1, '|');
            getline(ss, p2.name, '|');
            ss >> p2.budget;
            ss.ignore(1, '|');
            getline(ss, p2.manager, '|');
            ss.ignore(1,'|');
            getline(ss, p2.location, '|');

            if (p2.id == id) {
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new project name: ";
                getline(cin, p2.name);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new project budget: ";
                cin >> p2.budget;
                cin.ignore();
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new manager name: ";
                getline(cin, p2.manager);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new project location: ";
                getline(cin, p2.location);
                found = true;
            }

            tempFile << p2.id << "|" << p2.name << "|" << p2.budget << "|" << p2.manager << "|" << p2.location << endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("projects.txt");
            rename("temp.txt", "projects.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Project updated successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Project ID not found." << endl;
        }
    }
    
    // Remove Project Function
    void removeProject() {
        ifstream inFile("projects.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter project ID to remove: ";
        cin >> id;
        cin.ignore(); 

        Project p2;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> p2.id;
            ss.ignore(1, '|');
            getline(ss, p2.name, '|');
            ss >> p2.budget;
            ss.ignore(1, '|');
            getline(ss, p2.manager, '|');
            getline(ss, p2.location, '|');

            if (p2.id != id) {
                tempFile << p2.id << "|" << p2.name << "|" << p2.budget << "|" << p2.manager << "|" << p2.location << endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("projects.txt");
            rename("temp.txt", "projects.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Project removed successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Project ID not found." << endl;
        }
    }
    
    // Display Projects Function
    void displayProjects() {
        ifstream inFile("projects.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }
		cout<<endl<<endl<<endl;
        cout << "_______________________________Projects_______________________________" << endl<<endl;
        cout << "-----------------------------------------------------------------------" << endl;
        cout << "ID\tName\t\tBudget\t\tManager\t\tLocation" << endl;
        cout << "-----------------------------------------------------------------------" << endl<<endl<<endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            Project p2;
            ss >> p2.id;
            ss.ignore(1, '|');
            getline(ss, p2.name, '|');
            ss >> p2.budget;
            ss.ignore(1, '|');
            getline(ss, p2.manager, '|');
            getline(ss, p2.location, '|');

            cout  <<p2.id << "\t" << p2.name << "\t" << p2.budget << "\t\t" << p2.manager << "\t\t" << p2.location << endl;
            cout << "-----------------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};

	//Task Class

class Task{
	private:
	int TaskID, budget;
	string taskName, underProject;
    string assignedTo;
    string deadline;
    public:
    	
    	// Add Task Function
    void addTask() {
    	
        ofstream outFile("tasks.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        Task t1;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task ID: ";
        cin >> t1.TaskID;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task Name: ";
        getline(cin, t1.taskName);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task Budget : $";
        cin >> t1.budget;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Assigned Person Name: ";
        getline(cin, t1.assignedTo);
        cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter Assigned Team: ";
        getline(cin, t1.underProject);
		cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task Deadline: ";
        getline(cin, t1.deadline);

        outFile << t1.TaskID << "|" << t1.taskName << "|" << t1.budget << "|" << t1.assignedTo << "|" << t1.underProject<< "|"<<t1.deadline << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Task added successfully!" << endl;
    }
    
    // Update Task Function
    void updateTask() {
        ifstream inFile("tasks.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task ID to update: ";
        cin >> id;
        cin.ignore(); 

        Task t1;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> t1.TaskID;
            ss.ignore(1, '|');
            getline(ss, t1.taskName, '|');
            ss >> t1.budget;
            ss.ignore(1, '|');
            getline(ss, t1.assignedTo, '|');
			getline(ss,t1.underProject,'|');
            getline(ss, t1.deadline, '|');

            if (t1.TaskID == TaskID) {
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new task name: ";
                getline(cin, t1.taskName);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new task budget: ";
                cin >> t1.budget;
                cin.ignore(); 
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new assigned person name: ";
                getline(cin, t1.assignedTo);
                cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter new assigned team: ";
                getline(cin, t1.underProject);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new task deadline: ";
                getline(cin, t1.deadline);
                found = true;
            }

            tempFile << t1.TaskID << "|" << t1.taskName << "|" << t1.budget << "|" << t1.assignedTo << "|" << t1.underProject<<"|"<<t1.deadline << endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("tasks.txt");
            rename("temp.txt", "tasks.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Task updated successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Task ID not found." << endl;
        }
    }
    
    // Remove Task Function
    void removeTask() {
        ifstream inFile("tasks.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int TaskID;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Task ID to remove: ";
        cin >> TaskID;
        cin.ignore();

        Task t2;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> t2.TaskID;
            ss.ignore(1, '|');
            getline(ss, t2.taskName, '|');
            ss >> t2.budget;
            ss.ignore(1, '|');
            getline(ss, t2.assignedTo, '|');
            getline(ss, t2.underProject,'|');
            getline(ss, t2.deadline, '|');

            if (t2.TaskID != TaskID) {
                tempFile << t2.TaskID << "|" << t2.taskName << "|" << t2.budget << "|" << t2.assignedTo << "|" << t2.underProject <<"|"<<t2.deadline<< endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("tasks.txt");
            rename("temp.txt", "tasks.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Task removed successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Task ID not found." << endl;
        }
    }
    
    // Display Tasks Function
    void displayTasks() {
        ifstream inFile("tasks.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }
		cout<<endl<<endl;
        cout << "--------------------------Tasks-------------------------" << endl<<endl;
        cout << "-------------------------------------------------------------------------------------------------" << endl;
        cout << "ID\tName\t\tBudget\t\tAssigned Person\t\tAssigned Team\t\tDeadline" << endl;
        cout << "-------------------------------------------------------------------------------------------------" << endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            Task t2;
            ss >> t2.TaskID;
            ss.ignore(1, '|');
            getline(ss, t2.taskName, '|');
            ss >> t2.budget;
            ss.ignore(1, '|');
            getline(ss, t2.assignedTo, '|');
            getline(ss,t2.underProject,'|');
            getline(ss, t2.deadline, '|');

            cout << t2.TaskID << "    " << t2.taskName << "\t " << t2.budget << "\t\t   " << t2.assignedTo << "\t\t\t" << t2.underProject<<"\t\t\t "<<t2.deadline << endl;
            cout << "-------------------------------------------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};

	//Employees Class

class Employees {
	private:
		int ID,age;
        string name, gender, contactInfo, skills, designation;
		
	public:
	
	// Add Employee Function
	void addEmployee() {
        ofstream outFile("employees.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        Employees e1;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Employee ID: ";
        cin>>e1.ID;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Employee Name: ";
        getline(cin, e1.name);
        cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter Contact Info: ";
        getline(cin, e1.contactInfo);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Employee skills: ";
        getline(cin, e1.skills);
        cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter Employee Designation: ";
        getline(cin, e1.designation);
        cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter Employee Age: ";
        cin>>e1.age;
        cin.ignore();
        cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter Employee Gender: ";
        getline(cin, e1.gender);
        outFile << e1.ID << "|" << e1.name << "|" <<e1.contactInfo<<"|"<< e1.skills << "|"<<e1.designation<<"|"<<e1.age<<"|"<<e1.gender<<endl;

        outFile.close();
        cout<<endl;
        
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Employee added successfully!" << endl;
        cout << "-----------------------------------------------------------------------------------" << endl;
    }
    
    // Update Employee Function
    void updateEmployee() {
        ifstream inFile("employees.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Employee ID to update: ";
        cin >> id;
        cin.ignore(); 

        Employees e2;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> e2.ID;
            ss.ignore(1, '|');
            getline(ss, e2.name, '|');
            getline(ss, e2.contactInfo,'|');
            getline(ss, e2.skills,'|');
            getline(ss, e2.designation,'|');
			ss >> e2.age;
            ss.ignore(1, '|');
            getline(ss, e2.gender, '|');

            if (e2.ID == ID) {
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new employee name: ";
                getline(cin, e2.name);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new employee contact info: ";
                getline(cin ,e2.contactInfo);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new employee skills: ";
                getline(cin, e2.skills);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new employee designation: ";
                getline(cin, e2.designation);
                cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter new employee age: ";
                cin>>age;
                cin.ignore();
                cout<<"\t\t\t\t\t\t\t\t\t\t\t            Enter new employee Gender: ";
                getline(cin, e2.gender);
				found = true;
            }

            tempFile << e2.ID << "|" << e2.name << "|" << e2.contactInfo << "|" << e2.skills << "|" << e2.designation <<"|"<<e2.age<<"|"<<e2.gender<< endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("employees.txt");
            rename("temp.txt", "employees.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Employee updated successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Employee ID not found." << endl;
        }
    }
    
    // Remove Employee Fuction
    void removeEmployee() {
        ifstream inFile("employees.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Employee ID to remove: ";
        cin >> id;
        cin.ignore(); 

        Employees e2;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> e2.ID;
            ss.ignore(1, '|');
            getline(ss, e2.name, '|');
            getline(ss, e2.contactInfo,'|');
            getline(ss, e2.skills,'|');
            getline(ss, e2.designation,'|');
            ss >> e2.age;
            ss.ignore(1, '|');
            getline(ss, e2.gender, '|');

            if (e2.ID != ID) {
                tempFile << e2.ID << "|" << e2.name << "|" << e2.contactInfo << "|" << e2.skills << "|" << e2.designation <<"|"<<e2.age<<"|"<<e2.gender<< endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("employees.txt");
            rename("temp.txt", "employees.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Employee removed successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Employee ID not found." << endl;
        }
    }
	
	// Display Employees Function
    void displayEmployees() {
    ifstream inFile("employees.txt");
    if (!inFile) {
    	cout<<endl;
        cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
        return;
    }
    cout << "Employee Details:" << endl;
    cout << "-----------------------------------------------------------------------------------------------------------" << endl;
    cout << "ID\tName\t\tContact Info\t\tSkills\t\tDesignation\t  Age\t\tGender" << endl;
    cout << "-----------------------------------------------------------------------------------------------------------" << endl;

    string line;
    while (getline(inFile, line)) {
        stringstream ss(line);
        Employees e2;
        ss >> e2.ID;
        ss.ignore(1, '|');
        getline(ss, e2.name, '|');
        getline(ss, e2.contactInfo, '|');
        getline(ss, e2.skills, '|');
        getline(ss, e2.designation, '|');
        ss >> e2.age;
        ss.ignore(1, '|');
        getline(ss, e2.gender, '|');

        cout << e2.ID << "\t" << e2.name << "\t\t" << e2.contactInfo << "\t\t" << e2.skills << "\t" << e2.designation << "\t " << e2.age << "\t  " << e2.gender << endl;
       cout << "-----------------------------------------------------------------------------------------------------------" << endl;
    }

    inFile.close();
}

    
};
	//Recruitment Class
class Recruitment {
	private:
		string name;
        string contactInfo;
        string position;
	public:

    void addEmployee() {
        ofstream outFile("Recruit.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        Recruitment newEmployee;
        cin.ignore(); 
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter employee name: ";
        getline(cin, newEmployee.name);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter employee contact info: ";
        getline(cin, newEmployee.contactInfo);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter employee position: ";
        getline(cin, newEmployee.position);

        outFile << newEmployee.name << "|" << newEmployee.contactInfo << "|" << newEmployee.position << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Employee added successfully!" << endl;
        cout << "-------------------------------------------------------------" << endl;
    }

    void displayEmployees() {
        ifstream inFile("Recruit.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        cout << "Employee Details:" << endl;
        cout << "-------------------------------------------------------------" << endl;
        cout << "Name\t\tContact Info\t\tPosition" << endl;
        cout << "-------------------------------------------------------------" << endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            string name, contactInfo, position;
            getline(ss, name, '|');
            getline(ss, contactInfo, '|');
            getline(ss, position, '|');

            cout << name << "\t\t" << contactInfo << "\t\t" << position << endl;
         cout << "-------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};

	// Time Tracking Class

class TimeTracking {
	private:
		string name;
        string date;
        string checkInTime;
        string checkOutTime;
	public:
    void checkIn() {
        ofstream outFile("attendance.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        TimeTracking newAttendance;
        cout<<endl;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter employee name: ";
        getline(cin, newAttendance.name);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter date (YYYY-MM-DD): ";
        getline(cin, newAttendance.date);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter check-in time (HH:MM): ";
        getline(cin, newAttendance.checkInTime);

        
        outFile << newAttendance.name << "|" << newAttendance.date << "|" << newAttendance.checkInTime << "|" << "N/A" << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Check-in recorded successfully!" << endl;
        cout << "-------------------------------------------------------------" << endl;
    }

    void checkOut() {
        ifstream inFile("attendance.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        TimeTracking attendance;
        string name, date, checkOutTime;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter employee name: ";
        cin.ignore(); 
        getline(cin, name);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter date (YYYY-MM-DD): ";
        getline(cin, date);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter check-out time (HH:MM): ";
        getline(cin, checkOutTime);

        string line;
        bool found = false;
        while (getline(inFile, line)) {
            stringstream ss(line);
            getline(ss, attendance.name, '|');
            getline(ss, attendance.date, '|');
            getline(ss, attendance.checkInTime, '|');
            getline(ss, attendance.checkOutTime, '|');

            if (attendance.name == name && attendance.date == date && attendance.checkOutTime == "N/A") {
                attendance.checkOutTime = checkOutTime;
                found = true;
            }

            tempFile << attendance.name << "|" << attendance.date << "|" << attendance.checkInTime << "|" << attendance.checkOutTime << endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("attendance.txt");
            rename("temp.txt", "attendance.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Check-out recorded successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: No matching check-in record found." << endl;
        }

        cout << "-------------------------------------------------------------" << endl;
    }

    void displayAttendance() {
        ifstream inFile("attendance.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        cout << "Attendance Records:" << endl;
        cout << "-------------------------------------------------------------" << endl;
        cout << "Name\t\tDate\t\tCheck-In\tCheck-Out" << endl;
        cout << "-------------------------------------------------------------" << endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            string name, date, checkInTime, checkOutTime;
            getline(ss, name, '|');
            getline(ss, date, '|');
            getline(ss, checkInTime, '|');
            getline(ss, checkOutTime, '|');

            cout << name << "\t\t" << date << "\t" << checkInTime << "\t\t   " << checkOutTime << endl;
            cout << "-------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};

	// Inventory Management Class

class InventoryManagement {
	private:
		int id;
        string name;
        int quantity;
        string condition;
        string location;
	public:

    void addItem() {
        ofstream outFile("inventory.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        InventoryManagement newItem;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item ID: ";
        cin >> newItem.id;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item name: ";
        getline(cin, newItem.name);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item quantity: ";
        cin >> newItem.quantity;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item condition: ";
        getline(cin, newItem.condition);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item location: ";
        getline(cin, newItem.location);

        outFile << newItem.id << "|" << newItem.name << "|" << newItem.quantity << "|" << newItem.condition << "|" << newItem.location << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Item added successfully!" << endl;
    }

    void updateItem() {
        ifstream inFile("inventory.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item ID to update: ";
        cin >> id;
        cin.ignore();

        InventoryManagement item;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> item.id;
            ss.ignore(1, '|');
            getline(ss, item.name, '|');
            ss >> item.quantity;
            ss.ignore(1, '|');
            getline(ss, item.condition, '|');
            getline(ss, item.location, '|');

            if (item.id == id) {
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new item name: ";
                getline(cin, item.name);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new item quantity: ";
                cin >> item.quantity;
                cin.ignore(); 
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new item condition: ";
                getline(cin, item.condition);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new item location: ";
                getline(cin, item.location);
                found = true;
            }

            tempFile << item.id << "|" << item.name << "|" << item.quantity << "|" << item.condition << "|" << item.location << endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("inventory.txt");
            rename("temp.txt", "inventory.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Item updated successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Item ID not found." << endl;
        }
    }

    void removeItem() {
        ifstream inFile("inventory.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int id;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter item ID to remove: ";
        cin >> id;
        cin.ignore(); 

        InventoryManagement item;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> item.id;
            ss.ignore(1, '|');
            getline(ss, item.name, '|');
            ss >> item.quantity;
            ss.ignore(1, '|');
            getline(ss, item.condition, '|');
            getline(ss, item.location, '|');

            if (item.id != id) {
                tempFile << item.id << "|" << item.name << "|" << item.quantity << "|" << item.condition << "|" << item.location << endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("inventory.txt");
            rename("temp.txt", "inventory.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Item removed successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Item ID not found." << endl;
        }
    }

    void displayItems() {
        ifstream inFile("inventory.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        cout << "Inventory Items:" << endl;
        cout << "-------------------------------------------------------------" << endl;
        cout << "ID\tName\tQuantity\tCondition\tLocation" << endl;
        cout << "-------------------------------------------------------------" << endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            InventoryManagement item;
            ss >> item.id;
            ss.ignore(1, '|');
            getline(ss, item.name, '|');
            ss >> item.quantity;
            ss.ignore(1, '|');
            getline(ss, item.condition, '|');
            getline(ss, item.location, '|');

            cout << item.id << "\t" << item.name << "\t" << item.quantity << "\t\t" << item.condition << "\t\t" << item.location << endl;
            cout << "-------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};
	//TaskManagement Class

class TaskManagement {
	private:
		int taskId;
        string taskName;
        string supervisor;
        string team;
   
	public:
    
	void addTask() {
        ofstream outFile("supervisors.txt", ios::app);
        if (!outFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for writing." << endl;
            return;
        }

        TaskManagement newTask;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter task ID: ";
        cin >> newTask.taskId;
        cin.ignore(); 
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter task name: ";
        getline(cin, newTask.taskName);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter supervisor name: ";
        getline(cin, newTask.supervisor);
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter team (comma-separated list of team members): ";
        getline(cin, newTask.team);

        outFile << newTask.taskId << "|" << newTask.taskName << "|" << newTask.supervisor << "|" << newTask.team << endl;

        outFile.close();
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Task added successfully!" << endl;
    }

    void updateTask() {
        ifstream inFile("supervisors.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int taskId;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter task ID to update: ";
        cin >> taskId;
        cin.ignore(); 

        TaskManagement task;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> task.taskId;
            ss.ignore(1, '|');
            getline(ss, task.taskName, '|');
            getline(ss, task.supervisor, '|');
            getline(ss, task.team, '|');

            if (task.taskId == taskId) {
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new task name: ";
                getline(cin, task.taskName);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new supervisor name: ";
                getline(cin, task.supervisor);
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter new team (comma-separated list of team members): ";
                getline(cin, task.team);
                found = true;
            }

            tempFile << task.taskId << "|" << task.taskName << "|" << task.supervisor << "|" << task.team << endl;
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("supervisors.txt");
            rename("temp.txt", "supervisors.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Task updated successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Task ID not found." << endl;
        }
    }

    void removeTask() {
        ifstream inFile("supervisors.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        ofstream tempFile("temp.txt");
        if (!tempFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open temporary file for writing." << endl;
            return;
        }

        int taskId;
        cout<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter task ID to remove: ";
        cin >> taskId;
        cin.ignore(); 

        TaskManagement task;
        bool found = false;
        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            ss >> task.taskId;
            ss.ignore(1, '|');
            getline(ss, task.taskName, '|');
            getline(ss, task.supervisor, '|');
            getline(ss, task.team, '|');

            if (task.taskId != taskId) {
                tempFile << task.taskId << "|" << task.taskName << "|" << task.supervisor << "|" << task.team << endl;
            } else {
                found = true;
            }
        }

        inFile.close();
        tempFile.close();

        if (found) {
            remove("supervisors.txt");
            rename("temp.txt", "supervisors.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Task removed successfully!" << endl;
        } else {
            remove("temp.txt");
            cout<<endl;
            cout << "\t\t\t\t\t\t\t\t\t\t\t            Error: Task ID not found." << endl;
        }
    }

    void displayTasks() {
        ifstream inFile("supervisors.txt");
        if (!inFile) {
        	cout<<endl;
            cerr << "\t\t\t\t\t\t\t\t\t\t\t            Error: Unable to open file for reading." << endl;
            return;
        }

        cout << "Task Records:" << endl;
        cout << "-------------------------------------------------------------" << endl;
        cout << "ID\tName\t\tSupervisor\t\tTeam" << endl;
        cout << "-------------------------------------------------------------" << endl;

        string line;
        while (getline(inFile, line)) {
            stringstream ss(line);
            TaskManagement task;
            ss >> task.taskId;
            ss.ignore(1, '|');
            getline(ss, task.taskName, '|');
            getline(ss, task.supervisor, '|');
            getline(ss, task.team, '|');

            cout << task.taskId << "\t" << task.taskName << "\t\t" << task.supervisor << "\t\t" << task.team << endl;
            cout << "-------------------------------------------------------------" << endl;
        }

        inFile.close();
    }
};



int main() {
	system("color B");
    char choice , choice1;
    
        cout<<endl<<endl<<endl;
    	cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t\t  LOGIN PAGE\t"<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t\t  1-Sign IN\t"<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t\t  2-Sign UP\t"<<endl<<endl;
        cout<<"\t\t\t\t\t\t\t\t\t   ********************************************************"<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t    Enter Your Choice: ";
        cin  >> choice1;
        switch (choice1){
            case '1':
            
                cin.ignore();
                obj.login();
                break;
              
            case '2':
                cin.ignore();
                obj.signUP();
                break;
               
			default:
				cout<<"\t\t\t\t\t\t\t\t\t\t\t    Exiting...............";	
				break;
		}

		do{
		cout<<endl<<endl;
		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl;
		cout<<endl<<endl;
		
		cout<<"\t\t\t\t\t\t\t\t\t\t\tCONSTRUCTION COMPANY MANAGEMENT SYSTEM "<<endl<<endl<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            1- Manage Projects        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            2- Manage Tasks        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            3- Manage Employees        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            4- Recruitment        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            5- Time Tracking        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            6- Inventory Of Tools        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t            7- Supervisors        "<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\t               Exit:: E/e        "<<endl<<endl;
		cout<<"\t\t\t\t\t\t\t\t\t\t\tEnter choice:: ";
		cin>>choice;
	
		
	
        switch (choice) {

        case '1': {
		Project projects;
    	char choice;
		

    	do{
    		cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          PROJECT DETAIL"<<endl<<endl<<endl;
		
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Add Project"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            2- Update Project"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Remove Project"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            4- Display Projects"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            5- Exit"<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t           Enter Your Choice:: ";
        cin >> choice;

        switch (choice) {
            case '1':
                projects.addProject();
                break;
            case '2':
                projects.updateProject();
                break;
            case '3':
                projects.removeProject();
                break;
            case '4':
                projects.displayProjects();
                break;
                case '5':
                cout<<"\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......"<<endl;
                break;
            default:
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice!='5');
			
			}
			break;
            case '2': {
            	    
		Task tasks;
    	char choice;


    	do {
   			cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          TASK DETAIL"<<endl<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Add Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            2- Update Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Remove Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            4- Display Tasks"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            5- Exit"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                tasks.addTask();
                break;
            case '2':
                tasks.updateTask();
                break;
            case '3':
                tasks.removeTask();
                break;
            case '4':
                tasks.displayTasks();
                break;
            default:
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice!='5');
				
			}
			break;
			 case '3': {
			 	
	Employees employees;
    char choice;

    do {

    	   	cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          EMPLOYEE DETAIL"<<endl<<endl<<endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            1. Add Employee" << endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            2. Update Employee" << endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            3. Remove Employee" << endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            4. Display Employees" << endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            5. Exit" << endl;
        	cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter your choice: ";
        	cin >> choice;

        switch (choice) {
            case '1':
                employees.addEmployee();
                break;
            case '2':
                employees.updateEmployee();
                break;
            case '3':
              	employees.removeEmployee();
				break;
			case '4': 
				employees.displayEmployees();
				break;
			case '5':
				cout<<"\\t\t\t\t\t\t\t\t\t\t\t            Exiting Program........."<<endl;

				break;
            default:
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    } 
		while (choice != '5');
    }
				break;
				case '4':{
					 Recruitment recruitment;
    char choice;

    do{
    	   	cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          EMPLOYEE RECRUITMENT DETAIL"<<endl<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Add Employee"<<endl;

        
        cout << "\t\t\t\t\t\t\t\t\t\t\t            2- Display Employees"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Exit"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                recruitment.addEmployee();
                break;
            case '2':
                recruitment.displayEmployees();
                break;
            case '3':
            	cout<<endl;
            cout<<"\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......"<<endl;
                break;
            default:
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice !='3');
					
				}
				break;
				case '5': {
					TimeTracking timeTracking;
    char choice;
    do {
    	   	cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t            TIME TRACKING DETAIL"<<endl<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Check-In"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            2- Check-Out"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Display Attendance Records"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            4- Exit"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                timeTracking.checkIn();
                break;
            case '2':
                timeTracking.checkOut();
                break;
            case '3':
                timeTracking.displayAttendance();
                break;
            case '4':
            	cout<<endl;
            cout<<"\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......"<<endl;
                break;
            default:
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice!= '4');
					
				}
				break;
				
			case '6': {
				InventoryManagement inventory;
    char choice;

    do{
    	   	cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          TOOLS INVENTORY DETAIL"<<endl<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Add Item"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            2- Update Item"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Remove Item"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            4- Display Items"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            5- Exit"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                inventory.addItem();
                break;
            case '2':
                inventory.updateItem();
                break;
            case '3':
                inventory.removeItem();
                break;
            case '4':
                inventory.displayItems();
                break;
            case '5':
            	cout<<endl;
            cout<<"\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......"<<endl;
                break;
            default:
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice!='5');
				
			}
			break;
			case '7': {
				TaskManagement taskManagement;
    char choice;


    do {
    	   	cout<<endl<<endl;
    		cout << "\t\t\t\t\t\t\t\t\t____________________________________________________________________________" << endl<<endl;
    		
    		cout<<"\t\t\t\t\t\t\t\t\t\t\t          TASK SUPERVISORS DETAIL"<<endl<<endl<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            1- Add Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t 		    2- Update Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            3- Remove Task"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            4- Display Tasks"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            5- Exit"<<endl;
        cout << "\t\t\t\t\t\t\t\t\t\t\t            Enter Your Choice: ";
        cin >> choice;

        switch (choice) {
            case '1':
                taskManagement.addTask();
                break;
            case '2':
                taskManagement.updateTask();
                break;
            case '3':
                taskManagement.removeTask();
                break;
            case '4':
                taskManagement.displayTasks();
                break;
            case '5':
            	cout<<endl;
            cout<<"\\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......"<<endl;
                break;
            default:
            	cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!" << endl;
                break;
        }
    }
    while(choice!= '5');
				
			}
			break;
                case 'E' : case 'e': {
					cout<<endl;
                	cout<<"\t\t\t\t\t\t\t\t\t\t\t            Exiting Program......."<<endl;
                	break;
                }
			default:
				cout<<endl;
                cout << "\t\t\t\t\t\t\t\t\t\t\t            Invalid Selection...!";
                break;

                 }
        }
        while(choice!= 'E'&& choice!='e');
        
        
            return 0;
        }
 


